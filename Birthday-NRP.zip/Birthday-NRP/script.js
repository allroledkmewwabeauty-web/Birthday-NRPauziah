// ===== CONFETTI LUXURY =====
const colors = [
  "#d4af7a", // gold
  "#f5e6c8", // champagne
  "#eac4d5", // soft pink
  "#ede7db"  // ivory
];

const total = 100;

for (let i = 0; i < total; i++) {
  const c = document.createElement("span");
  c.style.position = "fixed";
  c.style.top = "-20px";
  c.style.left = Math.random() * 100 + "vw";
  c.style.width = Math.random() * 6 + 4 + "px";
  c.style.height = Math.random() * 16 + 10 + "px";
  c.style.backgroundColor =
    colors[Math.floor(Math.random() * colors.length)];
  c.style.opacity = Math.random() * 0.3 + 0.5;
  c.style.borderRadius = "2px";
  c.style.animation = `
    fall ${Math.random() * 6 + 7}s linear infinite,
    sway ${Math.random() * 4 + 4}s ease-in-out infinite
  `;
  document.body.appendChild(c);
}

const style = document.createElement("style");
style.innerHTML = `
@keyframes fall {
  to { transform: translateY(110vh); }
}
@keyframes sway {
  0%,100% { margin-left: 0; }
  50% { margin-left: 25px; }
}
`;
document.head.appendChild(style);

// FORM UCAPAN
const form = document.getElementById("wishForm");
const wishList = document.getElementById("wishList");

form.addEventListener("submit", e => {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const message = document.getElementById("message").value;

  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `<strong>${name}</strong><p>${message}</p>`;

  wishList.appendChild(card);
  form.reset();
});

const waBtn = document.getElementById("waShare");

const nama = "Neng Riska Pauziah";

const pesan = `Selamat Ulang Tahun ${nama} 🎂✨
Semoga selalu bahagia dan diberkahi kesehatan 🤍`;

waBtn.addEventListener("click", function (e) {
  e.preventDefault();

  const encodedText = encodeURIComponent(pesan);

  // Coba buka WhatsApp APP
  const appLink = "whatsapp://send?text=" + encodedText;

  // Fallback ke WhatsApp Web
  const webLink = "https://wa.me/+6283870442837?text=" + encodedText;

  // Deteksi Mobile
  if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
    window.location.href = appLink;

    // Jika gagal, fallback ke web
    setTimeout(() => {
      window.location.href = webLink;
    }, 1000);
  } else {
    // Desktop langsung ke web
    window.open(webLink, "_blank");
  }
});

function unmute() {
    const music = document.getElementById("bgMusic");
    music.muted = false;
}